# A.F.L Firebase Video Backend (v1.4 starter)

A deployable starter for A.F.L's 3-minute short-video upload pipeline.

## Architecture
- Firebase Authentication: phone/email identity (configure providers in Firebase Console)
- Cloud Firestore: video metadata and publishing state
- Firebase Storage: private original uploads and processed outputs
- Cloud Functions v2: authenticated upload-session API + Storage finalize trigger
- Cloud Run worker: FFmpeg validation, 1080p MP4 transcode, poster thumbnail
- Firebase Hosting: web deployment target (add the web app separately)

## Important
This is a source-code starter, not a deployed service. You must create a Firebase project, configure billing where required, set secrets/environment values, deploy the functions and Cloud Run worker, and register app platforms. Never commit service-account keys or `.env` secrets.

## 1. Create Firebase project
1. Create a Firebase project at https://console.firebase.google.com/
2. Enable Authentication -> Sign-in methods -> Phone and Email/Password.
3. Create Firestore in production mode.
4. Enable Storage.
5. Upgrade to the Blaze plan if required by Cloud Functions, Cloud Run, or your usage.
6. Install Node.js 20+, Firebase CLI, Google Cloud CLI, Docker.

## 2. Deploy Firebase rules and functions
From this folder:

```bash
npm install
cd functions && npm install && cd ..
firebase login
firebase use --add
firebase deploy --only firestore:rules,storage,functions
```

Create a Pub/Sub topic:
```bash
gcloud pubsub topics create afl-video-processing
```

Set the topic name for functions:
```bash
firebase functions:config:set afl.processing_topic="afl-video-processing"
```

For newer Functions config workflows, set `PROCESSING_TOPIC=afl-video-processing` as a function environment variable instead. The source uses `process.env.PROCESSING_TOPIC` with a default.

## 3. Deploy Cloud Run processor
The worker is a Pub/Sub push HTTP receiver. Build and deploy it:

```bash
gcloud builds submit --tag REGION-docker.pkg.dev/PROJECT_ID/afl/afl-video-worker ./worker
gcloud run deploy afl-video-worker \
  --image REGION-docker.pkg.dev/PROJECT_ID/afl/afl-video-worker \
  --region REGION \
  --no-allow-unauthenticated \
  --memory 2Gi \
  --cpu 2 \
  --timeout 900 \
  --set-env-vars FIREBASE_PROJECT_ID=PROJECT_ID
```

Grant the worker service account:
- Storage Object Viewer + Storage Object Creator (prefer bucket-scoped roles)
- Cloud Datastore User (or the minimum Firestore permissions required)

Create a Pub/Sub push subscription targeting the Cloud Run URL. Configure OIDC authentication with a service account that has `roles/run.invoker` on the Cloud Run service:

```bash
gcloud pubsub subscriptions create afl-video-worker-push \
  --topic=afl-video-processing \
  --push-endpoint=WORKER_URL \
  --push-auth-service-account=PUSH_SERVICE_ACCOUNT
```

The Cloud Functions service account needs `roles/pubsub.publisher` on the topic.

## 4. Configure client
Copy `client/firebase.example.ts` to your app and fill in Firebase web config from Project settings -> Your apps. Install:
```bash
npm install firebase
npx expo install expo-image-picker
```

Use `uploadVideo()` from `client/uploadVideo.ts` after the user signs in. This example is compatible with Expo's ImagePicker asset shape. For web, adapt file selection to provide a browser `File` object and upload with the Firebase Web SDK.

## 5. Firestore video document
Collection: `videos/{videoId}`

```json
{
  "ownerId": "firebase-auth-uid",
  "caption": "Optional caption",
  "privacy": "public",
  "status": "uploading",
  "originalPath": "users/UID/videos/VIDEO_ID/original",
  "processedPath": null,
  "thumbnailPath": null,
  "durationSeconds": null,
  "source": "gallery",
  "requestedQuality": "1080p",
  "soundEnabled": true,
  "createdAt": "server timestamp",
  "updatedAt": "server timestamp",
  "publishedAt": null,
  "failureReason": null
}
```

## 6. Upload flow
1. Client calls `createVideoUpload` callable function.
2. Function creates a Firestore video record and returns the Storage path.
3. Client uploads original to that path with resumable upload.
4. Storage finalize trigger publishes a Pub/Sub processing message.
5. Cloud Run worker downloads and validates media, transcodes to 1080p H.264/AAC, creates JPEG thumbnail, uploads outputs, then marks video `published`.
6. Feed queries only `status == "published"` and `privacy == "public"`.

## 7. Limits and production hardening
- The worker validates duration server-side; client checks are only UX.
- Set Storage upload size limits and App Check before public launch.
- Add moderation/review before publishing user-generated content.
- Add rate limits, abuse detection, quotas, deletion workflows, retention policies, and monitoring.
- Configure allowed video MIME types and test actual device codecs.
- 4K upload is not enabled in this first pipeline: source originals may be 4K, but output is normalized to 1080p. A separate 4K rendition can be added later.
- Private videos must be served through authenticated, authorized access; do not expose permanent public URLs for private content.
