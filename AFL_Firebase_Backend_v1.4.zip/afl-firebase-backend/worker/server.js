const express = require("express");
const { Storage } = require("@google-cloud/storage");
const admin = require("firebase-admin");
const { execFile } = require("child_process");
const { promisify } = require("util");
const fs = require("fs/promises");
const os = require("os");
const path = require("path");

admin.initializeApp({ projectId: process.env.FIREBASE_PROJECT_ID });
const db = admin.firestore();
const storage = new Storage();
const execFileAsync = promisify(execFile);
const app = express();
app.use(express.json({ limit: "1mb" }));

const MAX_SECONDS = 180;

app.post("/", async (req, res) => {
  // Pub/Sub push wraps the message in {message:{data:base64}, subscription:"..."}.
  let payload;
  try {
    const encoded = req.body?.message?.data;
    if (!encoded) return res.status(400).send("Missing Pub/Sub message");
    payload = JSON.parse(Buffer.from(encoded, "base64").toString("utf8"));
  } catch {
    return res.status(400).send("Invalid message");
  }

  const { bucket, objectPath, uid, videoId } = payload;
  if (!bucket || !objectPath || !uid || !videoId ||
      objectPath !== `users/${uid}/videos/${videoId}/original`) {
    return res.status(400).send("Invalid payload");
  }

  const ref = db.collection("videos").doc(videoId);
  const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "afl-"));
  const input = path.join(tempDir, "input");
  const output = path.join(tempDir, "video.mp4");
  const poster = path.join(tempDir, "thumbnail.jpg");

  try {
    const snap = await ref.get();
    if (!snap.exists || snap.data().ownerId !== uid) return res.status(204).send();
    const source = storage.bucket(bucket).file(objectPath);
    await source.download({ destination: input });

    const probe = await execFileAsync("ffprobe", [
      "-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1",input
    ]);
    const duration = Number(probe.stdout.trim());
    if (!Number.isFinite(duration) || duration <= 0 || duration > MAX_SECONDS) {
      await ref.update({ status:"failed", failureReason:"Video must be 1–180 seconds.", updatedAt: admin.firestore.FieldValue.serverTimestamp() });
      return res.status(204).send();
    }

    // Normalize portrait/landscape input to fit within 1920x1080 without stretching.
    await execFileAsync("ffmpeg", [
      "-y","-i",input,
      "-t",String(MAX_SECONDS),
      "-vf","scale='min(1920,iw)':'min(1080,ih)':force_original_aspect_ratio=decrease",
      "-c:v","libx264","-preset","veryfast","-crf","23",
      "-c:a","aac","-b:a","128k","-movflags","+faststart",
      output
    ]);
    await execFileAsync("ffmpeg", ["-y","-ss","1","-i",output,"-frames:v","1","-q:v","2",poster]);

    const outVideoPath = `videos/${videoId}/video.mp4`;
    const outPosterPath = `videos/${videoId}/thumbnail.jpg`;
    await storage.bucket(bucket).upload(output, { destination:outVideoPath, metadata:{ contentType:"video/mp4", cacheControl:"private,max-age=3600" } });
    await storage.bucket(bucket).upload(poster, { destination:outPosterPath, metadata:{ contentType:"image/jpeg", cacheControl:"private,max-age=3600" } });

    await ref.update({
      status:"published",
      processedPath:outVideoPath,
      thumbnailPath:outPosterPath,
      durationSeconds:Math.round(duration),
      publishedAt:admin.firestore.FieldValue.serverTimestamp(),
      updatedAt:admin.firestore.FieldValue.serverTimestamp(),
      failureReason:null
    });
    return res.status(204).send();
  } catch (err) {
    console.error("AFL video processing failed", err);
    await ref.update({ status:"failed", failureReason:"Video processing failed.", updatedAt:admin.firestore.FieldValue.serverTimestamp() }).catch(()=>{});
    return res.status(500).send("Processing failed");
  } finally {
    await fs.rm(tempDir, { recursive:true, force:true });
  }
});

app.get("/health", (_req,res) => res.status(200).send("A.F.L worker ready"));
app.listen(process.env.PORT || 8080, () => console.log("A.F.L worker listening"));
