import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { getStorage } from "firebase-admin/storage";
import { PubSub } from "@google-cloud/pubsub";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { onObjectFinalized } from "firebase-functions/v2/storage";

initializeApp();
const db = getFirestore();
const pubsub = new PubSub();
const TOPIC = process.env.PROCESSING_TOPIC || "afl-video-processing";
const MAX_DURATION_SECONDS = 180;

export const createVideoUpload = onCall({ region: "asia-south1", enforceAppCheck: false }, async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign in to upload videos.");

  const caption = typeof request.data?.caption === "string" ? request.data.caption.trim() : "";
  const privacy = request.data?.privacy;
  const source = request.data?.source;

  if (caption.length > 2200) throw new HttpsError("invalid-argument", "Caption is too long.");
  if (!["public", "private", "followers"].includes(privacy)) {
    throw new HttpsError("invalid-argument", "Invalid privacy setting.");
  }
  if (!["gallery", "camera"].includes(source)) {
    throw new HttpsError("invalid-argument", "Invalid upload source.");
  }

  const videoRef = db.collection("videos").doc();
  const uid = request.auth.uid;
  const originalPath = `users/${uid}/videos/${videoRef.id}/original`;

  await videoRef.create({
    ownerId: uid,
    caption,
    privacy,
    source,
    status: "uploading",
    requestedQuality: "1080p",
    soundEnabled: true,
    originalPath,
    processedPath: null,
    thumbnailPath: null,
    durationSeconds: null,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
    publishedAt: null,
    failureReason: null
  });

  return { videoId: videoRef.id, originalPath, maxDurationSeconds: MAX_DURATION_SECONDS };
});

export const onOriginalVideoUploaded = onObjectFinalized({ region: "asia-south1" }, async (event) => {
  const object = event.data;
  const path = object.name || "";
  const match = path.match(/^users\/([^/]+)\/videos\/([^/]+)\/original$/);
  if (!match || !object.bucket) return;

  const [, uid, videoId] = match;
  const videoRef = db.collection("videos").doc(videoId);
  const snap = await videoRef.get();
  if (!snap.exists || snap.data()?.ownerId !== uid) return;

  if (!object.contentType?.startsWith("video/")) {
    await videoRef.update({ status: "failed", failureReason: "Unsupported media type", updatedAt: FieldValue.serverTimestamp() });
    return;
  }

  await videoRef.update({ status: "processing", updatedAt: FieldValue.serverTimestamp() });
  await pubsub.topic(TOPIC).publishMessage({
    json: { bucket: object.bucket, objectPath: path, uid, videoId }
  });
});

// Called by a trusted worker only. Do not expose this endpoint to clients.
// The Cloud Run worker uses Firebase Admin credentials and updates Firestore directly.
