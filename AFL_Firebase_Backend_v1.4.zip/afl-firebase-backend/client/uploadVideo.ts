import { httpsCallable } from "firebase/functions";
import { ref, uploadBytesResumable } from "firebase/storage";
import { functions, storage, auth } from "./firebase";

type UploadOptions = {
  file: Blob;
  caption?: string;
  privacy?: "public" | "private" | "followers";
  source?: "gallery" | "camera";
  onProgress?: (percent: number) => void;
};

export async function uploadVideo(options: UploadOptions) {
  if (!auth.currentUser) throw new Error("Please sign in first.");
  if (!options.file.type.startsWith("video/")) throw new Error("Select a video file.");
  if (options.file.size > 500 * 1024 * 1024) throw new Error("Video exceeds the 500 MB upload limit.");

  const createSession = httpsCallable(functions, "createVideoUpload");
  const response: any = await createSession({
    caption: options.caption ?? "",
    privacy: options.privacy ?? "public",
    source: options.source ?? "gallery"
  });
  const { videoId, originalPath } = response.data;

  const task = uploadBytesResumable(ref(storage, originalPath), options.file, {
    contentType: options.file.type,
    customMetadata: { videoId }
  });

  await new Promise<void>((resolve, reject) => {
    task.on("state_changed",
      snapshot => options.onProgress?.(
        snapshot.totalBytes ? snapshot.bytesTransferred / snapshot.totalBytes * 100 : 0
      ),
      reject,
      () => resolve()
    );
  });

  return { videoId, status: "processing" as const };
}
