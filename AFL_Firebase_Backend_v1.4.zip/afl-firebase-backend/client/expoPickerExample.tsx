// Example usage in an Expo React Native screen.
// Install: npx expo install expo-image-picker
import * as ImagePicker from "expo-image-picker";
import { uploadVideo } from "./uploadVideo";

export async function chooseAndUploadVideo() {
  const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!permission.granted) throw new Error("Gallery permission is required.");

  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ["videos"],
    allowsEditing: false,
    quality: 1
  });
  if (result.canceled || !result.assets?.[0]) return null;

  const asset = result.assets[0];
  if (asset.duration && asset.duration > 180_000) {
    throw new Error("A.F.L videos can be up to 3 minutes long.");
  }

  const response = await fetch(asset.uri);
  const blob = await response.blob();

  return uploadVideo({
    file: blob,
    caption: "",
    privacy: "public",
    source: "gallery",
    onProgress: percent => console.log(`Upload ${Math.round(percent)}%`)
  });
}
